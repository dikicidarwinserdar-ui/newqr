# CDP Verification Backend

## Local
```bash
cp .env.example .env
docker compose up --build
```

API:
- Backend: http://localhost:3000
- CDP service: http://localhost:8000
- PostgreSQL: localhost:5432

## Render Deploy
1. Bu klasörü GitHub reposuna yükle.
2. Render > New > Blueprint seç.
3. GitHub reposunu bağla.
4. `render.yaml` dosyasını seç.
5. Deploy sonrası env ayarları:
   - `BACKEND_PUBLIC_URL`: Render backend URL
   - `PUBLIC_APP_URL`: Netlify frontend URL
   - `CDP_SERVICE_URL`: Render cdp-service URL

## Ana Endpointler
```http
POST /labels
GET /labels
GET /lots/:id
POST /lots/:id/reference
POST /verification/:lotId
GET /verification/page/:token
```

Create label body:
```json
{
  "profileNo": "P-100",
  "alloy": "6063",
  "surfaceColor": "RAL9005"
}
```
