from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import cv2
import numpy as np
from pathlib import Path

app = FastAPI(title="CDP Similarity Service")

class CompareRequest(BaseModel):
    referencePath: str
    capturedPath: str

def load_image(path: str):
    p = Path(path)
    if not p.exists():
        p = Path("/app") / path
    img = cv2.imread(str(p))
    if img is None:
        raise HTTPException(400, f"Image not readable: {path}")
    return img

def normalize(img):
    img = cv2.resize(img, (360, 360), interpolation=cv2.INTER_AREA)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.equalizeHist(l)
    return cv2.merge([l, a, b])

def ssim_gray(a, b):
    a = cv2.cvtColor(a, cv2.COLOR_LAB2BGR)
    b = cv2.cvtColor(b, cv2.COLOR_LAB2BGR)
    a = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY).astype("float32")
    b = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY).astype("float32")
    C1, C2 = 6.5025, 58.5225
    mu1, mu2 = cv2.GaussianBlur(a, (11,11), 1.5), cv2.GaussianBlur(b, (11,11), 1.5)
    sigma1 = cv2.GaussianBlur(a*a, (11,11), 1.5) - mu1*mu1
    sigma2 = cv2.GaussianBlur(b*b, (11,11), 1.5) - mu2*mu2
    sigma12 = cv2.GaussianBlur(a*b, (11,11), 1.5) - mu1*mu2
    ssim = ((2*mu1*mu2 + C1) * (2*sigma12 + C2)) / ((mu1*mu1 + mu2*mu2 + C1) * (sigma1 + sigma2 + C2))
    return float(np.clip(ssim.mean(), 0, 1))

def hist_similarity(a, b):
    scores = []
    for ch in range(3):
        ha = cv2.calcHist([a], [ch], None, [64], [0,256])
        hb = cv2.calcHist([b], [ch], None, [64], [0,256])
        cv2.normalize(ha, ha); cv2.normalize(hb, hb)
        scores.append(cv2.compareHist(ha, hb, cv2.HISTCMP_CORREL))
    return float(np.clip(np.mean(scores), 0, 1))

def binary_similarity(a, b):
    ag = cv2.cvtColor(cv2.cvtColor(a, cv2.COLOR_LAB2BGR), cv2.COLOR_BGR2GRAY)
    bg = cv2.cvtColor(cv2.cvtColor(b, cv2.COLOR_LAB2BGR), cv2.COLOR_BGR2GRAY)
    _, ab = cv2.threshold(ag, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    _, bb = cv2.threshold(bg, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    equal = np.mean(ab == bb)
    return float(equal)

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/compare")
def compare(req: CompareRequest):
    ref = normalize(load_image(req.referencePath))
    cap = normalize(load_image(req.capturedPath))
    ssim = ssim_gray(ref, cap)
    hist = hist_similarity(ref, cap)
    binary = binary_similarity(ref, cap)
    score = (ssim * 0.45 + binary * 0.35 + hist * 0.20) * 100
    return {
        "score": round(float(score), 2),
        "ssim": round(ssim * 100, 2),
        "binary": round(binary * 100, 2),
        "colorHistogram": round(hist * 100, 2),
        "note": "MVP score. Real calibration needs reference/copy dataset."
    }
