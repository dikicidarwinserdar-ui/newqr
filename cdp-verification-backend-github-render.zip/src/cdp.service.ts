import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import QRCode from 'qrcode';
import { createCanvas } from 'canvas';

@Injectable()
export class CdpService {
  private uploadDir = process.env.UPLOAD_DIR || './uploads';

  ensureDir(dir: string) { fs.mkdirSync(dir, { recursive: true }); }

  makeHash(parts: string[]) {
    return crypto.createHash('sha256').update(parts.map(x => x.trim().toLowerCase()).join('|')).digest('hex');
  }

  async generateCdp(labelHash: string): Promise<string> {
    const dir = path.join(this.uploadDir, 'cdp');
    this.ensureDir(dir);
    const filePath = path.join(dir, `${labelHash}.png`);
    if (fs.existsSync(filePath)) return filePath;

    const size = 360;
    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, size, size);

    let seed = crypto.createHash('sha256').update(labelHash).digest();
    function rnd(i: number) { return seed[i % seed.length] / 255; }

    for (let i = 0; i < 2200; i++) {
      const x = Math.floor(rnd(i) * size);
      const y = Math.floor(rnd(i + 7) * size);
      const r = 1 + Math.floor(rnd(i + 13) * 4);
      const red = Math.floor(30 + rnd(i + 2) * 210);
      const green = Math.floor(30 + rnd(i + 3) * 210);
      const blue = Math.floor(30 + rnd(i + 4) * 210);
      ctx.fillStyle = `rgb(${red},${green},${blue})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
      if (i % 31 === 0) seed = crypto.createHash('sha256').update(seed).digest();
    }

    fs.writeFileSync(filePath, canvas.toBuffer('image/png'));
    return filePath;
  }

  async generateQr(token: string): Promise<string> {
    const dir = path.join(this.uploadDir, 'qr');
    this.ensureDir(dir);
    const backendUrl = process.env.BACKEND_PUBLIC_URL || 'http://localhost:3000';
    const target = `${backendUrl}/verification/page/${token}`;
    const filePath = path.join(dir, `${token}.png`);
    await QRCode.toFile(filePath, target, { width: 512, margin: 2 });
    return filePath;
  }

  publicPath(filePath?: string | null) {
    if (!filePath) return null;
    return '/' + filePath.replace(/\\/g, '/').replace(/^\.?\/*uploads\//, 'uploads/');
  }
}
