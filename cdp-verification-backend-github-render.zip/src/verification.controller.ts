import { Controller, Get, Param, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { VerificationService } from './verification.service';

@Controller('verification')
export class VerificationController {
  constructor(private verification: VerificationService) {}

  @Get('page/:token')
  page(@Param('token') token: string) { return this.verification.page(token); }

  @Post(':lotId')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: './uploads/captured',
      filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '-')}`)
    })
  }))
  verify(@Param('lotId') lotId: string, @UploadedFile() file: Express.Multer.File) {
    return this.verification.verifyByLot(lotId, file.path);
  }
}
