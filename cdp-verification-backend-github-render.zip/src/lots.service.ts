import { Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { nanoid } from 'nanoid';

@Injectable()
export class LotsService {
  constructor(private prisma: PrismaService) {}
  async createForLabel(labelId: string) {
    return this.prisma.lot.create({
      data: { labelId, lotCode: `LOT-${Date.now()}-${nanoid(5)}`, verifyToken: nanoid(32) }
    });
  }
  async saveReference(lotId: string, path: string) {
    return this.prisma.lot.update({ where: { id: lotId }, data: { referenceImagePath: path } });
  }
  get(id: string) {
    return this.prisma.lot.findUnique({ where: { id }, include: { label: true, attempts: { orderBy: { createdAt: 'desc' } } } });
  }
}
