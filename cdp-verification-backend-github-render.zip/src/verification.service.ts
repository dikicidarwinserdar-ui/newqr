import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import axios from 'axios';

@Injectable()
export class VerificationService {
  constructor(private prisma: PrismaService) {}

  classify(score: number) {
    if (score >= 80) return 'VERIFIED';
    if (score >= 55) return 'SUSPICIOUS';
    return 'COPY';
  }

  async verifyByLot(lotId: string, capturedPath: string) {
    const lot = await this.prisma.lot.findUnique({ where: { id: lotId }, include: { label: true } });
    if (!lot?.referenceImagePath) throw new BadRequestException('Reference image is missing for this lot.');

    const serviceUrl = process.env.CDP_SERVICE_URL || 'http://localhost:8000';
    const { data } = await axios.post(`${serviceUrl}/compare`, {
      referencePath: lot.referenceImagePath,
      capturedPath
    });

    const score = Number(data.score || 0);
    const result = this.classify(score) as any;

    return this.prisma.verificationAttempt.create({
      data: { lotId, capturedImagePath: capturedPath, similarityScore: score, result, details: data },
      include: { lot: { include: { label: true } } }
    });
  }

  async page(token: string) {
    const lot = await this.prisma.lot.findUnique({ where: { verifyToken: token }, include: { label: true } });
    if (!lot) throw new BadRequestException('Invalid QR token.');
    return lot;
  }
}
