import { Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { CreateLabelDto } from './dto';
import { CdpService } from './cdp.service';
import { LotsService } from './lots.service';

@Injectable()
export class LabelsService {
  constructor(private prisma: PrismaService, private cdp: CdpService, private lots: LotsService) {}

  async createOrGet(dto: CreateLabelDto) {
    const labelHash = this.cdp.makeHash([dto.profileNo, dto.alloy, dto.surfaceColor]);
    let label = await this.prisma.productLabel.findUnique({ where: { labelHash } });
    let created = false;

    if (!label) {
      const cdpPath = await this.cdp.generateCdp(labelHash);
      label = await this.prisma.productLabel.create({
        data: { ...dto, labelHash, cdpPath }
      });
      created = true;
    }

    const lot = await this.lots.createForLabel(label.id);
    const qrPath = await this.cdp.generateQr(lot.verifyToken);
    await this.prisma.productLabel.update({ where: { id: label.id }, data: { qrPath } });

    return { created, label: { ...label, cdpUrl: this.cdp.publicPath(label.cdpPath), qrUrl: this.cdp.publicPath(qrPath) }, lot };
  }

  list() {
    return this.prisma.productLabel.findMany({ include: { lots: true }, orderBy: { createdAt: 'desc' } });
  }
}
