import { Controller, Get, Param, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { LotsService } from './lots.service';

@Controller('lots')
export class LotsController {
  constructor(private lots: LotsService) {}
  @Get(':id') get(@Param('id') id: string) { return this.lots.get(id); }

  @Post(':id/reference')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: './uploads/references',
      filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '-')}`)
    })
  }))
  uploadReference(@Param('id') id: string, @UploadedFile() file: Express.Multer.File) {
    return this.lots.saveReference(id, file.path);
  }
}
