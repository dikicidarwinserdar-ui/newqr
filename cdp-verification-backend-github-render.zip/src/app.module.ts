import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { PrismaService } from './prisma.service';
import { LabelsController } from './labels.controller';
import { LabelsService } from './labels.service';
import { LotsController } from './lots.controller';
import { LotsService } from './lots.service';
import { VerificationController } from './verification.controller';
import { VerificationService } from './verification.service';
import { CdpService } from './cdp.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ServeStaticModule.forRoot({ rootPath: join(process.cwd(), 'uploads'), serveRoot: '/uploads' })
  ],
  controllers: [LabelsController, LotsController, VerificationController],
  providers: [PrismaService, LabelsService, LotsService, VerificationService, CdpService],
})
export class AppModule {}
