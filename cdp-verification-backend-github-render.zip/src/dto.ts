import { IsNotEmpty, IsString } from 'class-validator';

export class CreateLabelDto {
  @IsString() @IsNotEmpty() profileNo!: string;
  @IsString() @IsNotEmpty() alloy!: string;
  @IsString() @IsNotEmpty() surfaceColor!: string;
}
