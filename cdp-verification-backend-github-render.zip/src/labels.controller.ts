import { Body, Controller, Get, Post } from '@nestjs/common';
import { CreateLabelDto } from './dto';
import { LabelsService } from './labels.service';

@Controller('labels')
export class LabelsController {
  constructor(private labels: LabelsService) {}
  @Post() create(@Body() dto: CreateLabelDto) { return this.labels.createOrGet(dto); }
  @Get() list() { return this.labels.list(); }
}
